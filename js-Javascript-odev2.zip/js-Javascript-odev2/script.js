let chartInstance = null;

document.getElementById("startBtn").addEventListener("click", () => {
  const resultDiv = document.getElementById("result");
  const loadingDiv = document.getElementById("loading");
  const stepsDiv = document.getElementById("chainSteps");
  const chartCanvas = document.getElementById("chainChart");

  resultDiv.innerHTML = "";
  stepsDiv.innerHTML = "";
  loadingDiv.style.display = "block";

  setTimeout(() => {
    const memo = {};
    let maxLength = 0;
    let numberWithMax = 0;
    let longestChain = [];

    const collatzSequence = (n) => {
      const sequence = [n];
      while (n !== 1) {
        if (n % 2 === 0) {
          n = n / 2;
        } else {
          n = 3 * n + 1;
        }
        sequence.push(n);
      }
      return sequence;
    };

    const collatzLength = (n) => {
      let original = n;
      let count = 0;
      while (n !== 1) {
        if (memo[n]) {
          count += memo[n];
          break;
        }
        if (n % 2 === 0) {
          n = n / 2;
        } else {
          n = 3 * n + 1;
        }
        count++;
      }
      memo[original] = count;
      return count;
    };

    for (let i = 1; i < 1000000; i++) {
      const len = collatzLength(i);
      if (len > maxLength) {
        maxLength = len;
        numberWithMax = i;
      }
    }

    longestChain = collatzSequence(numberWithMax);

    loadingDiv.style.display = "none";
    resultDiv.innerHTML = `
      ✅ <strong>Result:</strong><br>
      Number with longest chain: <strong>${numberWithMax}</strong><br>
      Chain length: <strong>${longestChain.length}</strong>
    `;

    stepsDiv.innerHTML = longestChain.join(" → ");

    // Önceki grafik varsa sil
    if (chartInstance) {
      chartInstance.destroy();
    }

    // Yeni grafik oluştur
    chartInstance = new Chart(chartCanvas, {
      type: 'line',
      data: {
        labels: longestChain.map((_, i) => i + 1),
        datasets: [{
          label: 'Collatz Sequence Values',
          data: longestChain,
          borderColor: 'cyan',
          borderWidth: 2,
          fill: false,
          pointRadius: 2
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: true }
        },
        scales: {
          x: {
            title: {
              display: true,
              text: 'Step'
            }
          },
          y: {
            title: {
              display: true,
              text: 'Value'
            }
          }
        }
      }
    });

  }, 100);
});

